require('../../modules/es6.array.filter');
module.exports = require('../../modules/_core').Array.filter;
